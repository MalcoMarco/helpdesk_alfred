<?php $__env->startSection('template_title'); ?>
    <?php echo e(trans('installer_messages.environment.wizard.templateTitle')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <i class="fa fa-magic fa-fw" aria-hidden="true"></i>
    <?php echo trans('installer_messages.environment.wizard.title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
    <div class="tabs tabs-full">

        <form method="post" action="<?php echo e(route('LaravelInstaller::environmentSaveInfo')); ?>" class="tabs-wrap">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group <?php echo e($errors->has('app_pce') ? ' has-error ' : ''); ?>">
                <label for="app_pce">
                    <?php echo e('Purchase Code'); ?>

                </label>
                <input type="text" name="app_pce" id="app_pce" value="" placeholder="<?php echo e('input your purchase code'); ?>" />
                <?php if($errors->has('app_pce')): ?>
                    <span class="error-block">
                            <i class="fa fa-fw fa-exclamation-triangle" aria-hidden="true"></i>
                            <?php echo e('The purchase code is required.'); ?>

                        </span>
                <?php endif; ?>
            </div>

            <div class="buttons">
                <button class="button">
                    <?php echo e(trans('installer_messages.environment.info.button')); ?>

                    <i class="fa fa-angle-right fa-fw" aria-hidden="true"></i>
                </button>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.installer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfredco/public_html/helpdesk.alfred.com.do/resources/views/vendor/installer/environment_info.blade.php ENDPATH**/ ?>