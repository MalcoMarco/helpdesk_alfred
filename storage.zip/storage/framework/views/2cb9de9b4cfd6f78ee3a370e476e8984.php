
<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <h3>TRANSACCIONES</h3>

    <form method="POST" action="<?php echo e(@route('transaccion.store')); ?>" class="d-inline-flex mb-4" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="input-group">
            <input type="file" name="transaccion_file" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload" accept=".xls,.xlsx,.csv" required>
            <button class="btn btn-outline-success" type="submit" id="inputGroupFileAddon04">SUBIR</button>
        </div>
    </form>

    <?php if(sizeof($transaccions)>0): ?>
        <div class="w-100 text-end mb-1">
            <a href="<?php echo e(@route('transaccion.download')); ?>" target="_blank" class="btn btn-success">Descargar</a>
        </div>
    <?php endif; ?>

    <div class="w-100">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger col-12">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>  

    <div class="w-100 table-responsive mb-4">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Número de Cuenta</th>
                    <th>Banco</th>
                    <th>Tipo de Cuenta</th>
                    <th>Cliente</th>
                    <th>Tipo de Mov.</th>
                    <th>Monto</th>
                    <th>Referencia</th>
                    <th>Descripción</th>
                    <th>Email</th>
                    <th>Fax</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transaccions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($t->num_cuenta); ?></td>
                    <td><?php echo e($t->codigo_banco); ?></td>
                    <td><?php echo e($t->tipo_cuenta); ?></td>
                    <td><?php echo e($t->nombre_cliente); ?></td>
                    <td><?php echo e($t->tipo_movimiento); ?></td>
                    <td><?php echo e($t->monto); ?></td>
                    <td><?php echo e($t->referencia); ?></td>
                    <td><?php echo e($t->descripcion); ?></td>
                    <td><?php echo e($t->email); ?></td>
                    <td><?php echo e($t->fax); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.transaccions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\augus\OneDrive\Documentos\GitHub\helpdesk\resources\views/transaccions/index.blade.php ENDPATH**/ ?>