<?php $__env->startSection('template_title'); ?>
    <?php echo e(trans('installer_messages.final.templateTitle')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <i class="fa fa-flag-checkered fa-fw" aria-hidden="true"></i>
    <?php echo e(trans('installer_messages.final.title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

    <p class="mt-2 max-w-3xl text-center mx-auto">
        You have successfully completed the installation process, you can visit homepage or login now!
    </p>

    <div class="buttons">
        <a href="<?php echo e(url('/')); ?>" target="_blank" class="button">Home</a>
        <a href="<?php echo e(url('/login')); ?>" target="_blank" class="button">Login</a>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.installer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alfredco/public_html/helpdesk.alfred.com.do/resources/views/vendor/installer/finished.blade.php ENDPATH**/ ?>